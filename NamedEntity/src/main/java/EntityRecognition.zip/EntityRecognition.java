import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.Span;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class EntityRecognition {

    public static void main(String[] args) {
        String tokens[] = {};
        Span spans[] = {};
        try {
            InputStream tokenStream = new FileInputStream("en-token.bin");

            InputStream locationModelStream = new FileInputStream(new File("en-ner-location.bin"));

            TokenizerModel tm = new TokenizerModel(tokenStream);

            TokenizerME tokenizer = new TokenizerME(tm);

            TokenNameFinderModel tnfm = new TokenNameFinderModel(locationModelStream);

            NameFinderME nf = new NameFinderME(tnfm);

            String sentence = "Enid is located north of Oklahoma City.";

            tokens = tokenizer.tokenize(sentence);

            spans = nf.find(tokens);
        }
        catch(Exception e){
        }

        for(int i = 0; i < spans.length; i++){
            System.out.println(spans[i]);
        }

    }

    public void lol(){
    }


    }
